def reverse_rotate(li):
    return li[-1:] + li[:-1]


def reverse_Add(li):
    return li[:-1]


def reverse_Swap(li):
    return li[1:2] + li[:1]+ li[2:]


def q3(s, instruction_count = 0):
    if len(s)== 0:
        return instruction_count
    ref = 'ABCDEFGH'[:len(s)]
    s = list(s)
    li_ref = [0,1,2]
    li_functions = [reverse_rotate, reverse_Add, reverse_Swap]
    if str(s[-1]) == ref[len(s)-1]:
        s.remove(s[-1])
        instruction_count +=1
        q3(s)
    closest = s.index(ref[-1]), s
    for i in li_functions:
        li= i(s)
        new = li.index(ref[-1])
        if new == 2:
            s = li
            break
        if new < closest[1].index(ref[-1]):
            closest = new, i(s)
    s = closest[1]
    instruction_count +=1
    print(s)
    return q3(s, instruction_count)



print(q3('ACBD'))